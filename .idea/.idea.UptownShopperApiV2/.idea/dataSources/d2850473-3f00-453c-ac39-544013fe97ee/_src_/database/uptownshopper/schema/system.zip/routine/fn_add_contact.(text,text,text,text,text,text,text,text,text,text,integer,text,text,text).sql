create function system.fn_add_contact(_first_name text, _middle_name text, _last_name text, _display_name text, _user_id text, _email text, _mobile_phone text, _home_phone text, _work_phone text, _fax text, _department integer, _title text, _notes text, _created_by text) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
  result int;
BEGIN
  INSERT INTO system.contact (
    first_name, middle_name, last_name, display_name, user_id, email, mobile_phone, home_phone, work_phone, fax, department, title, notes, date_created, created_by
  )
  VALUES(
    _first_name, _middle_name, _last_name, _display_name, _user_id, _email, _mobile_phone, _home_phone, _work_phone, _fax,  _department, _title, _notes, public.getdate(), _created_by
  );

  SELECT CURRVAL(pg_get_serial_sequence('system.contact','id')) INTO result;

  RETURN result;
END
$$;
