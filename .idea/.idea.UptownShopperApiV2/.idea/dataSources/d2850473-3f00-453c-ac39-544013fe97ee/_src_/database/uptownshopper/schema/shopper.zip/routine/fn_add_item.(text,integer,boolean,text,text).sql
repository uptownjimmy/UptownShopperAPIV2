create function shopper.fn_add_item(_name text, _item_type integer, _active boolean, _notes text, _created_by text) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
  result int;
BEGIN
  INSERT INTO shopper.item (
    name, item_type, active, notes, date_created, created_by
  )
  VALUES(
    _name, _item_type, _active, _notes, public.getdate(), _created_by
  );

  SELECT CURRVAL(pg_get_serial_sequence('shopper.item','id')) INTO result;

  RETURN result;
END
$$;
