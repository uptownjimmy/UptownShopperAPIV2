create function shopper.fn_delete_item(_item_id bigint) returns void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE shopper.item
  SET
    date_deleted = public.getdate()
  WHERE id = _item_id;
END
$$;
