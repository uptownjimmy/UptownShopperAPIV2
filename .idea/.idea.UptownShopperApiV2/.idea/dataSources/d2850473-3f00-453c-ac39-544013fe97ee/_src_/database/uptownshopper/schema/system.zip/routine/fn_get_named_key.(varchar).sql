create function system.fn_get_named_key(_key_type character varying) returns TABLE(id bigint, key_value character varying, key_text character varying, sort_index integer)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  select
    nk.id,
    nk.key_value,
    nk.key_text,
    nk.sort_index
  FROM system.named_key nk
  WHERE nk.date_deleted is null
      AND (nk.key_type = _key_type or nullif(_key_type, null) is null)
  ORDER BY sort_index ASC;
END
$$;
