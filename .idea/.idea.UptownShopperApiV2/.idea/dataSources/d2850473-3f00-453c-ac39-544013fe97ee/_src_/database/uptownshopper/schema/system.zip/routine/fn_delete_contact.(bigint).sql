create function system.fn_delete_contact(_contact_id bigint) returns void
LANGUAGE plpgsql
AS $$
BEGIN
   UPDATE system.contact
    SET
        date_deleted = getdate()
    WHERE id = _contact_id;
END
$$;
