create function shopper.fn_get_store_item(_store_id bigint) returns TABLE(item_id bigint, item_name character varying, item_type integer, item_active boolean, item_notes character varying, item_created_by character varying, item_modified_by character varying, store_id bigint, store_name character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  select
    i.id AS item_id,
    i.name AS item_name,
    i.item_type AS item_type,
    i.active AS item_active,
    i.notes AS item_notes,
    i.created_by AS item_created_by,
    i.modified_by AS item_modified_by,
    s.id AS store_id,
    s.name AS store_name
  FROM shopper.store_item si
  JOIN shopper.item i
    ON i.id = si.item_id
    AND i.date_deleted IS NULL 
  JOIN shopper.store s
    ON s.id = _store_id
    AND s.date_deleted IS NULL 
  WHERE si.store_id = _store_id
    AND si.date_deleted is null
  ORDER BY item_name ASC;
END
$$;
