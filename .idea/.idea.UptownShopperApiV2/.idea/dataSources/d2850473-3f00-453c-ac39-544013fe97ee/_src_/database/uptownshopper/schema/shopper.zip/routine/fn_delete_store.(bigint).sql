create function shopper.fn_delete_store(_store_id bigint) returns void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE shopper.store
  SET
    date_deleted = public.getdate()
  WHERE id = _store_id;
END
$$;
