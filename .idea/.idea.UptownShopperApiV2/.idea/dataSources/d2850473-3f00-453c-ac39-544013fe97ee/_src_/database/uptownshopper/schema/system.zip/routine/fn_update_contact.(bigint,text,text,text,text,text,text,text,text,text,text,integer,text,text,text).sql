create function system.fn_update_contact(_contact_id bigint, _first_name text, _middle_name text, _last_name text, _display_name text, _user_id text, _email text, _mobile_phone text, _home_phone text, _work_phone text, _fax text, _department integer, _title text, _notes text, _modified_by text) returns void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE system.contact
  SET
    first_name = _first_name,
    middle_name = _middle_name,
    last_name = _last_name,
    display_name = _display_name,
    user_id = _user_id,
    email = _email,
    mobile_phone = _mobile_phone,
    home_phone = _home_phone,
    work_phone = _work_phone,
    fax = _fax,
    department = _department,
    title = _title,
    notes = _notes,
    date_modified = public.getdate(),
    modified_by = _modified_by
  WHERE id = _contact_id;
END
$$;
