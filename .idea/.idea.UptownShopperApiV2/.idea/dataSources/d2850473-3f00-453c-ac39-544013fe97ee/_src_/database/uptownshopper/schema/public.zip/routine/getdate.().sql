create function getdate() returns timestamp with time zone
LANGUAGE SQL
AS $$
select now()
$$;
