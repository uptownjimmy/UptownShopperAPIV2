create function shopper.fn_get_store(_store_id bigint) returns TABLE(id bigint, name character varying, location character varying, store_type integer, created_by character varying, modified_by character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  select
    s.id,
    s.name,
    s.location,
    s.store_type,
    s.created_by,
    s.modified_by
  FROM shopper.store s
  WHERE s.date_deleted is null
        AND (s.id = _store_id or nullif(_store_id, null) is null);
END
$$;
