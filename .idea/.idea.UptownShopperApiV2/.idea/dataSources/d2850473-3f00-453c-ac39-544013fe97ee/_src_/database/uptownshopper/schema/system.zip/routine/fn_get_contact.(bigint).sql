create function system.fn_get_contact(_contact_id bigint) returns TABLE(id bigint, first_name character varying, middle_name character varying, last_name character varying, display_name character varying, user_id character varying, email character varying, mobile_phone character varying, home_phone character varying, work_phone character varying, fax character varying, department integer, title character varying, notes character varying, created_by character varying, modified_by character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  select
    c.id,
    c.first_name,
    c.middle_name,
    c.last_name,
    c.display_name,
    c.user_id,
    c.email,
    c.mobile_phone,
    c.home_phone,
    c.work_phone,
    c.fax,
    c.department,
    c.title,
    c.notes,
    c.created_by,
    c.modified_by
  FROM system.contact c
  WHERE c.date_deleted is null
        AND (c.id = _contact_id or nullif(_contact_id, null) is null);
END
$$;
