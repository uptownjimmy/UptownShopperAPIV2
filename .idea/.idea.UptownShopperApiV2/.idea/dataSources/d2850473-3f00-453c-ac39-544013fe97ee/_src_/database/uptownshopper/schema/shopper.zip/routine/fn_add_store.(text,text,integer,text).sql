create function shopper.fn_add_store(_name text, _location text, _store_type integer, _created_by text) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
  result int;
BEGIN
  INSERT INTO shopper.store (
    name, location, store_type, date_created, created_by
  )
  VALUES(
    _name, _location, _store_type, public.getdate(), _created_by
  );

  SELECT CURRVAL(pg_get_serial_sequence('shopper.store','id')) INTO result;

  RETURN result;
END
$$;
