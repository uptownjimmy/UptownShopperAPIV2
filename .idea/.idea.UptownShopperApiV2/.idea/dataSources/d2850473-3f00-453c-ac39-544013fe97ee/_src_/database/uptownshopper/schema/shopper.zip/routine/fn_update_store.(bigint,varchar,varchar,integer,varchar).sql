create function shopper.fn_update_store(_store_id bigint, _name character varying, _location character varying, _store_type integer, _modified_by character varying) returns void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE shopper.store
  SET
    name = _name,
    location = _location,
    store_type = _store_type,
    date_modified = public.getdate(),
    modified_by = _modified_by
  WHERE id = _store_id;
END
$$;
