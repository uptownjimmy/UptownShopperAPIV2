create function information_schema."_pg_keysequal"(smallint[], smallint[]) returns boolean
LANGUAGE SQL
AS $$
select $1 operator(pg_catalog.<@) $2 and $2 operator(pg_catalog.<@) $1
$$;
