create function shopper.fn_add_store_item(_store_id integer, _item_id integer, _created_by text) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
  result int;
BEGIN
  INSERT INTO shopper.store_item (
    store_id, item_id, date_created, created_by
  )
  VALUES(
    _store_id, _item_id, public.getdate(), _created_by
  );

  SELECT CURRVAL(pg_get_serial_sequence('shopper.store_item','id')) INTO result;

  RETURN result;
END
$$;
